# MyLibrary
A simple library management system written in Python.

## Installation

```
pip install .
```

## Usage

```
python main.py
```

